package com.example.dinewise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinewiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
