package com.example.dinewise.model;

public  enum ApplicationStatus {
    pending,
    approved,
    rejected
    
}