package com.example.dinewise.model;

public enum ManagerStatus {
    running,
    past

}

