package com.example.dinewise.service;

import com.example.dinewise.model.Stock;
import java.util.List;

public interface StockService {
    List<Stock> getAllStocks();
}

